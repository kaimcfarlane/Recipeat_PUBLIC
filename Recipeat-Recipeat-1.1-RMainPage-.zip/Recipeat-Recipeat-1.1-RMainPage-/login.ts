console.log("Login typescript working")

//We need to add a button that checks if hash matches inputted hash, if so the button will go to link 

// var username = (<HTMLInputElement>document.getElementById("username")).value;
// var password = (<HTMLInputElement> document.getElementById("password")).value;
function logButton() {

}