# Recipeat

A recipe app that saves the personal recipes you create along with the relevant health information associated for it. Built encrypted 
user-authentification/login/logout features via Node.js, Passport.js and MongoDB. Used MongoDB to save user recipes and currently designing 
front-end of application using EJS (Embedded JavaScript), TypeScript, CSS, and HTML.
